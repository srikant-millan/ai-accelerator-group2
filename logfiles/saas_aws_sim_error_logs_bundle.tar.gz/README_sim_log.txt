# Simulated DevOps Error Logs — SaaS on AWS (Gateways, ECS, Database)

Generated: 2025-11-08T13:02:19.646326Z

## Files
- `saas_aws_sim_error_log.ndjson` — Canonical, structured log stream (mixed sources).
- `saas_aws_sim_error_log_small.ndjson` — First ~80 events for quick tests.
- `saas_aws_sim_error_log_alb.log` — ALB access-style error lines (502 surge).
- `saas_aws_sim_error_log_rds.log` — Aurora PostgreSQL error/slow query excerpts.
- `saas_aws_sim_error_log_ecs_events.log` — ECS agent/service event lines.

## Scenarios Included
1. **API Gateway throttling (HTTP 429)** around minute +2 (`source=apigw`).
2. **Aurora connection exhaustion** and **deadlocks** around minutes +4 to +6 (`source=db/aurora`).
3. **Slow queries** around minute +8 (`source=db/aurora`, `errno=slow_query`).
4. **ECS Orders task OOMKilled** around minutes +11 to +12 (`source=ecs/agent`).
5. **ALB 502 surge** mapping to the crashing tasks (`source=alb/access`).
6. **Gateway 504 upstream timeouts** around minute +12 (`source=gateway`).

## Core Fields (NDJSON)
- `@timestamp` — ISO8601 UTC with millisecond precision.
- `level` — INFO | WARN | ERROR
- `source` — ecs/app | ecs/agent | alb/access | apigw | gateway | db/aurora
- `message` — Human-readable summary.
- `request_id`, `trace_id`, `span_id` — Correlation identifiers.
- `service`, `cluster`, `task_definition`, `container` — ECS metadata.
- `http_method`, `http_path`, `http_status`, `latency_ms` — HTTP context (if applicable).
- `region`, `az`, `vpc_id`, `subnet_id` — AWS placement.
- `db_instance`, `db`, `db_user`, `errno` — DB metadata (if applicable).

## Notes
- Timestamps span ~15 minutes on 2025-11-08 around 09:50–10:05 UTC.
- Correlation: many ALB 502 and gateway 504s occur during `ecs/agent` OOMKilled events for `orders-service`.
- Use `trace_id`/`request_id` to tie layers (gateway ⇄ ECS ⇄ DB).

## Example Queries (CloudWatch Logs / OpenSearch)
- ECS 5xx rate: source="ecs/app" and http_status >= 500 | stats count() by bin(1m)
- DB deadlocks: source="db/aurora" and errno="deadlock_detected"
- ALB 5xx over time: source="alb/access" and elb_status_code=502 | stats count() by bin(1m)
- Throttling rate: source="apigw" and http_status=429
